
 @extends('layout.frontend.front')

 @section('title', 'Home')
 
 @section('content')
    
    
 <div class="cs-slider cs-style1">
    <div class="cs-slider_container" data-autoplay="0" data-loop="1" data-speed="600" data-center="0" data-slides-per-view="1">
      <div class="cs-slider_wrapper">
        @if ($slide)
          @foreach ($slide as $item)
            <div class="cs-slide">
              <div class="cs-banner cs-style1">
                <img src="{{asset($item->image)}}" alt="">
              </div>
            </div>
          @endforeach
        @endif
      </div>
    </div>
    <div class="cs-pagination cs-style1"></div>
  </div>
  <div class="cs-height_35 cs-height_lg_35"></div>
  
  @if($category)
    @foreach($category as $cat)
      <div class="container cs-card_wrap_1">
        <div class="cs-seciton_heading cs-style2">
          <h2 class="cs-seciton_title"><span>{{$cat->name}}</span></h2>
        </div>
        <div class="cs-card_grip_2">
          <div class="cs-card_out">
            <a href="#" class="cs-brand"><img src="{{asset($cat->lsb_image)}}" alt=""></a>
          </div>
          @php
            $products=App\Models\Product::where('category_id',$cat->id)->orderBy('id','DESC')->paginate(8);
          @endphp
          @if($products)
            @foreach ($products as $item)
              <div class="cs-card_out">
                <a href="{{route('front.product',$item->id)}}" class="cs-card cs-style1">
                  <div class="cs-card_img"><img src='{{asset("$item->feature_image")}}' alt="Item"></div>
                  @if($item->outofstock_product==1)
                    <div class="cs-card_alert cs-out_of_stock">Out Of Stock</div>
                  @elseif($item->limited_product==1)
                    <div class="cs-card_alert">Limited Stock</div>
                  @elseif($item->feature_product==1)
                  <div class="cs-card_alert">Available</div>
                  @elseif($item->new_product==1)
                  <div class="cs-card_alert cs-new_item">New Arrival</div>
                  @else
                  <div class="cs-card_alert">Available</div>
                  @endif
                  <div class="cs-card_info">
                    <div class="cs-card_desc">{{$item->name}}</div>
                    @if($item->discount>0)
                    <div class="cs-card_price"><span>AED</span> {{number_format(($item->price - ($item->price * ($item->discount/100))),2)}}</div>
                    <div class="cs-card_previous_price">AED {{number_format($item->price,2)}}</div>
                    @else
                    <div class="cs-card_price"><span>AED</span> {{number_format($item->price,2)}}</div>
                    @endif
                  </div>
                </a>
              </div>
            @endforeach
          @endif
        </div>
      </div>
      <div class="cs-height_30 cs-height_lg_30"></div>
    @endforeach
  @endif
  <div class="cs-height_80 cs-height_lg_60"></div>
 
 @endsection